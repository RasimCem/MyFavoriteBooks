package com.example.myfavoritebooks;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.PostHolder> {
    private ArrayList<String> userMails;
    private ArrayList<String> bookNames;
    private ArrayList<String> authors;
    private ArrayList<String> abouts;
    private ArrayList<String> images;

    public RecyclerAdapter(ArrayList<String> userMails, ArrayList<String> bookNames, ArrayList<String> authors, ArrayList<String> abouts, ArrayList<String> images) {
        this.userMails = userMails;
        this.bookNames = bookNames;
        this.authors = authors;
        this.abouts = abouts;
        this.images = images;
    }

    @NonNull
    @Override
    public PostHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater= LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.recycleriew_row,parent,false);
        return new PostHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostHolder holder, int position) {
        holder.userMailText.setText(userMails.get(position));
        holder.bookNameText.setText(bookNames.get(position));
        holder.authorText.setText(authors.get(position));
        holder.aboutText.setText(abouts.get(position));
       // Picasso.get().load(images.get(position)).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return userMails.size();
    }

    class PostHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView userMailText,authorText,bookNameText,aboutText;

        public PostHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            userMailText = itemView.findViewById(R.id.userMailText);
            authorText = itemView.findViewById(R.id.authorText);
            bookNameText = itemView.findViewById(R.id.bookNameText);
            aboutText = itemView.findViewById(R.id.aboutText);

        }
    }
}
